package com.carsales.carsalesystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarsaleSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
